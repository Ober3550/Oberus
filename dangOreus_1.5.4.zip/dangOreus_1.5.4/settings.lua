data:extend({
    {
        type = "int-setting",
        name = "starting radius",
        setting_type = "runtime-global",
        default_value = 50,
        minimum_value = 0,
        maximum_value = 500,
        order = "01"
    },
	{
        type = "int-setting",
        name = "simple ore radius",
        setting_type = "runtime-global",
        default_value = 120,
        minimum_value = 0,
        maximum_value = 400,
        order = "02"
    },
	{
        type = "bool-setting",
        name = "easy mode",
        setting_type = "runtime-global",
        default_value = false,
        order = "03"
    },
    {
        type = "bool-setting",
        name = "floor is lava",
        setting_type = "runtime-global",
        default_value = false,
        order = "04"
    },
    {
        type = "string-setting",
        name = "dangOre mode",
        setting_type = "runtime-global",
        default_value = "pie",
        allowed_values = { "random", "perlin", "voronoi", "pie", "spiral" },
        order = "05"
    },
    {
        type = "double-setting",
        name = "voronoi scale factor",
        setting_type = "runtime-global",
        default_value = 3.0,
        minimum_value = 0.1,
        maximum_value = 50.0,
        order = "06"
    }
})