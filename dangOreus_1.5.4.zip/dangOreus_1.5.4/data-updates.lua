for k, v in pairs(data.raw.resource) do
	if v.category == "basic-fluid" then
		v.autoplace.coverage = 5 * v.autoplace.coverage
        --Boost oil in starting area
        v.autoplace.peaks[2] = 
        {
          influence = 0.1,
          starting_area_weight_optimal = 1,
          starting_area_weight_range = 0,
          starting_area_weight_max_range = 1,
        }
	end
end