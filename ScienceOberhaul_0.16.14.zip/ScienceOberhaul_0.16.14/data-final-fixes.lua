require('prototypes.recipe.science')
require('prototypes.recipe.intermediates')
require('prototypes.technology.technology')
