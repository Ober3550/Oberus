--Make Lazy Bastard Possible
if mods["aai-industry"] then
  data.raw.lab["burner-lab"].inputs = {"science-pack-1"}
end

if mods.bobelectronics then
data.raw.technology['advanced-electronics-3'].unit =
{
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 30,
      count = 100
}
end

--Require Lab Mk2 for High tech and Space science
data.raw.lab["lab"].inputs = {"science-pack-1","science-pack-2","science-pack-3","military-science-pack","logistic-science-pack","production-science-pack","token-bio"}

--Reorder the dependancies of science packs
bobmods.lib.tech.add_recipe_unlock("advanced-electronics-2", "production-science-pack")
bobmods.lib.tech.add_recipe_unlock("advanced-electronics-3", "high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-electronics-2","high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-material-processing-2","production-science-pack")
data.raw.technology["advanced-research"].prerequisites = {"advanced-electronics-2","bob-logistics-4"}
bobmods.lib.tech.add_new_science_pack("advanced-research","production-science-pack",1)
bobmods.lib.tech.add_new_science_pack("advanced-research","logistic-science-pack",1)
data.raw.technology["advanced-electronics-3"].prerequisites = {"advanced-electronics-2","advanced-research"}

if mods.SpaceMod then
bobmods.lib.tech.add_new_science_pack("spaceship-command","military-science-pack",1)
bobmods.lib.tech.add_new_science_pack("ftl-theory-D","military-science-pack",1)
bobmods.lib.tech.add_new_science_pack("ftl-propulsion","military-science-pack",1)
end